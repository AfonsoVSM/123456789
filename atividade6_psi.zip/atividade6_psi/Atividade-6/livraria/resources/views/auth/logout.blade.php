<a href="{{route('logout')}}">
	onclick="event.preventDefault();
	document.getElementByld('logout.form').submit();">
	Logout
</a>

<form action="{{route('logout')}}" method="POST" style="display: none;">
	@csrf
</form>