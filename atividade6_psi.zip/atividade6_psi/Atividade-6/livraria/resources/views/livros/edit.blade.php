<form action="{{route('livros.update', ['id'=>$livro->id_livro])}}" method="post">
@csrf
@method('patch')
Tilulo: <input type="text" name="titulo" value="{{$livro->titulo}}"><br>
@if ( $errors->has('titulo') )
Devera indicar um titulo valido<br>
@endif

Idioma: <input type="text" name="idioma" value="{{$livro->idioma}}"><br>
@if ( $errors->has('idioma') )
Devera indicar um idioma valido<br>
@endif

Data Ediçao: <input type="date" name="data_edicao" value="{{$livro->data_edicao}}"><br>
@if ( $errors->has('data_edicao') )
Devera indicar uma data edicao valido<br>
@endif

Total paginas: <input type="numeric" name="total_paginas" value="{{$livro->total_paginas}}"><br>
@if ( $errors->has('total_paginas') )
Devera indicar um total paginas valido<br>
@endif

ISBN: <input type="text" name="isbn" value="{{$livro->isbn}}"><br>
@if ( $errors->has('isbn') )
Devera indicar um isbn correto (13carateres)<br>
@endif

Observaçoes: <textarea name="observacoes" value="{{$livro->observacoes}}"></textarea><br>
@if ( $errors->has('observacoes') )
Devera indicar um observacoes valido<br>
@endif

Imagem capa: <input type="text" name="imagem capa" value="{{$livro->imagem_capa}}"><br>
@if ( $errors->has('imagem_capa') )
Devera indicar uma imagem capa valido<br>
@endif

Genero: <input type="numeric" name="id_genero" value="{{$livro->id_genero}}"><br>
@if ( $errors->has('genero') )
Devera indicar um genero valido<br>
@endif

Autor: <input type="text" name="id_autor" value="{{$livro->id_autor}}"><br>
@if ( $errors->has('autor') )
Devera indicar um autor valido<br>
@endif

Sinopse: <textarea name="sinopse" value="{{$livro->sinopse}}"></textarea><br>
@if ( $errors->has('sinopse') )
Devera indicar um sinopse valido<br>
@endif

<input type="submit" value="Enviar"><br>
</form>