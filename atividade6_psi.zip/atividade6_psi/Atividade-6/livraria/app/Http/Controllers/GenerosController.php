<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Genero;

class GenerosController extends Controller
{
 public function index(){
   	//$generos = Genero::all()->sortbydesc('idg');
   	$generos = Genero::paginate(4);

   	return view('generos.index', ['generos'=>$generos
   ]);

   }

   public function create(){

   return view ('generos.create');

  
   
}
public function store(Request $request){
   $novoGenero = $request->validate([
      'designacao'=>['required','min:3','max:100'],
      'observacoes'=>['nullable','min:3','max:200'],
  
   ]);

   $genero = Genero::create($novoGenero);

   return redirect()->route('generos.show',[
      'id'=>$genero->id_genero
   ]);

}

       public function show (Request $request){
	$idGenero=$request->id;

	
	$genero=Genero::where('id_genero', $idGenero)->with('livro')->first();

	return view('generos.show',  ['genero'=>$genero
]);
}
}
