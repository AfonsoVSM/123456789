<form action="<?php echo e(route('generos.store')); ?>" method="post">
<?php echo csrf_field(); ?>
Designacao: <input type="text" name="designacao"><br><br>
Observacoes: <input type="text" name="observacoes"><br><br>

<input type="submit" value="Enviar">
</form><?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/generos/create.blade.php ENDPATH**/ ?>