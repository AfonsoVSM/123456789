ID:<?php echo e($livro->id_livro); ?><br>
Titulo:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>
<?php /**PATH D:\rafapsi_at-6\Atividade-6\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>