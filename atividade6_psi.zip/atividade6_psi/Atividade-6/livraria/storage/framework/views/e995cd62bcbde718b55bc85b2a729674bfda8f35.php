<h2>deseja eliminar o livro</h2>
<h2><?php echo e($livro->titulo); ?></h2>
<form method="post" action="<?php echo e(route('livros.destroy',['id'=>$livro->id_livro])); ?>">
<?php echo csrf_field(); ?>
<?php echo method_field('delete'); ?>
<input type="submit" name="enviar">
</form>

<?php if(session()->has('mensagem')): ?>
         <div class="alert alert-danger" role="alert">
         <?php echo e(session ('mensagem')); ?>

         </div>
         <?php endif; ?><?php /**PATH D:\atividade6_psi\Atividade-6\livraria\resources\views/livros/delete.blade.php ENDPATH**/ ?>