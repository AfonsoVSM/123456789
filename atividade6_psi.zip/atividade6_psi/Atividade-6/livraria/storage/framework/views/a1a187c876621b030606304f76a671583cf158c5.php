ID:<?php echo e($livro->id_livro); ?><br>
Titulo:<?php echo e($livro->titulo); ?><br>
Idioma:<?php echo e($livro->idioma); ?><br>
Data edicao:<?php echo e($livro->data_edicao); ?><br>
Total paginas:<?php echo e($livro->total_paginas); ?><br>
Isbn:<?php echo e($livro->isbn); ?><br>
Observaçoes:<?php echo e($livro->observacoes); ?><br>
Imagem capa:<?php echo e($livro->imagem_capa); ?><br>
Genero:<?php echo e($livro->id_genero); ?><br>
Autor:<?php echo e($livro->id_autor); ?><br>
Sinopse:<?php echo e($livro->sinopse); ?><br>
<a href="<?php echo e(route('livros.edit', ['id'=>$livro->id_livro])); ?>">Editar</a>
<a href="<?php echo e(route('livros.delete', ['id'=>$livro->id_livro])); ?>">Eliminar</a>


<?php /**PATH D:\at6_psi\Atividade-6\livraria\resources\views/livros/show.blade.php ENDPATH**/ ?>