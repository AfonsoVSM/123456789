<form action="<?php echo e(route('livros.update', ['id'=>$livro->id_livro])); ?>" method="post">
<?php echo csrf_field(); ?>
<?php echo method_field('patch'); ?>
Tilulo: <input type="text" name="titulo" value="<?php echo e($livro->titulo); ?>"><br>
<?php if( $errors->has('titulo') ): ?>
Devera indicar um titulo valido<br>
<?php endif; ?>

Idioma: <input type="text" name="idioma" value="<?php echo e($livro->idioma); ?>"><br>
<?php if( $errors->has('idioma') ): ?>
Devera indicar um idioma valido<br>
<?php endif; ?>

Data Ediçao: <input type="date" name="data_edicao" value="<?php echo e($livro->data_edicao); ?>"><br>
<?php if( $errors->has('data_edicao') ): ?>
Devera indicar uma data edicao valido<br>
<?php endif; ?>

Total paginas: <input type="numeric" name="total_paginas" value="<?php echo e($livro->total_paginas); ?>"><br>
<?php if( $errors->has('total_paginas') ): ?>
Devera indicar um total paginas valido<br>
<?php endif; ?>

ISBN: <input type="text" name="isbn" value="<?php echo e($livro->isbn); ?>"><br>
<?php if( $errors->has('isbn') ): ?>
Devera indicar um isbn correto (13carateres)<br>
<?php endif; ?>

Observaçoes: <textarea name="observacoes" value="<?php echo e($livro->observacoes); ?>"></textarea><br>
<?php if( $errors->has('observacoes') ): ?>
Devera indicar um observacoes valido<br>
<?php endif; ?>

Imagem capa: <input type="text" name="imagem capa" value="<?php echo e($livro->imagem_capa); ?>"><br>
<?php if( $errors->has('imagem_capa') ): ?>
Devera indicar uma imagem capa valido<br>
<?php endif; ?>

Genero: <input type="numeric" name="id_genero" value="<?php echo e($livro->id_genero); ?>"><br>
<?php if( $errors->has('genero') ): ?>
Devera indicar um genero valido<br>
<?php endif; ?>

Autor: <input type="text" name="id_autor" value="<?php echo e($livro->id_autor); ?>"><br>
<?php if( $errors->has('autor') ): ?>
Devera indicar um autor valido<br>
<?php endif; ?>

Sinopse: <textarea name="sinopse" value="<?php echo e($livro->sinopse); ?>"></textarea><br>
<?php if( $errors->has('sinopse') ): ?>
Devera indicar um sinopse valido<br>
<?php endif; ?>

<input type="submit" value="Enviar"><br>
</form><?php /**PATH D:\atividade6_psi\Atividade-6\livraria\resources\views/livros/edit.blade.php ENDPATH**/ ?>